Creator - Tyler BoddySpargo 
June 3, 2012

FileHelper is a mass file manipulator for helping the user organize his/her files and folders.

It combines the following possibilities for two classes of objects:

(Let's assumer the file or folder object is named "f")

for Files:
append text to the file name at the beginning or at the end			 	f.appendNameBeg(string) / f.appendNameEnd(string)
remove text from the file name						 		f.removeFromName(string)
change extension										f.changeExt(string)


for Folders (a subclass of Files):\
Move folder contents to new destination directory					f.moveContents(destination)
Merge two directories, deleting old one							f.mergeDirs(FolderObjectB)
Find duplicate files recursively within the given directory				f.findDupes()
Remove the directory name from the name of all the files in that directory		f.removeDirName()
append the directory name to all the files in that directory				f.appendDirName()
recursively search the items in the directory for a string				f.searchDir(string)


To Use:
	to use this program, you will need to go into the if __name__ part of the code (Bottom) and provide files and or folders from your own computer using this code for example (or the methods mentioned above):

fA = Folder(path)
fB = Folder(path)
fA.mergeDirs(fB)

Outputs:
Many of the methods perform actions, however some do not. findDupes() will return to the user a list of lists of duplicate file objects, and searchDir(string) will return a list of the query results as file objects.

Bugs: the GUI doesn't work.  Tkinter proved to be more complicated that I had foreseen.  I was unable to get it to interact with the functionality of the program in a useful way. If you would like to see what it does do (I managed to get it to work with the mergers function) in the if __name__ part of then application (bottom) comment out what is there and type "fileHelper(path)" giving it, of course, a useful path from which it will start. It succeeds at being a file browser, but little more.

Note:
	the GUI itself uses a class called MyListBox that is not inconsequential and will hopefully prove useful in the final GUI



The GUI was the most challenging part, followed by the find duplicates function which posed many problems regarding the "sameness" of files and how that is determined.



With more time I will actually succeed and producing a GUI that is intuitive and efficient.