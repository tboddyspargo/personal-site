#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Created by Tyler BoddySpargo for CS 111 Final project at Carleton College
Version: 0.1.1
Date: February 12, 2013

"""
#Accepts Files and Folders input from the user and performs actions on them
#Possible actions include:
	#Files:
		#Append to name
		#remove from name
		#change extention
		#change extention of all same-type files in current directory
		#replace text in name
	#Folders:
		#Merge two folders
		#Move files into another destination folder
		#search directory for string
		#Find Duplicates - within single directory, or by comparing two directories
		#Append directory name to files in that directory
		#remove directory name from files in that directory
	#Folder Contents:
		#Move up heirarchical level
		#append text to all filenames
		#remove text from all filenames
		#replace text in all filesnames
#To do:
	#Impliment drag and drop possibilities with UI and into/out of UI from external sources.
	#Improve UI (Use Cocao)
	#rewrite program in C
	#Select multiple items and apply action to them
	#Idea: move files x heirarchies deep y heirarchies up

"""
Useful os methods:

os.chdir(path) - change current directory
os.getcwd() - get current working directory
os.mkdir(path) - make directory
os.makedirs(path) - makes directory with all necessary subdirectories to create leaf directory
os.remove(path) - delete file with path
os.rmdir(path) - deletes directory if empty
os.removedirs(path) - deletes leaf directory and each parent directory if they are empty.
os.rename(src, dst) rename the file or directory src to dst (if dst is a file, it will be replaced silently)

STATS:
os.stat(path) provides objects whose attributes are members of the stat structure:
os.stat(path).st_size - size of file in bytes
os.stat(path).st_mtime - time of most recent modification
os.stat(path).st_atime - time of most recent access
os.stat(path).st_birthtime - time of creation
os.stat(path).st_uid or stgid - owner's user id and group id

OR:

os.path.*(path)
	* = isdir, isfile, getatime, getctime, getsize, getmtime
		split (path becomes head, tail where tail is string after slash and head is everything else
		splitext (path becomes root, ext where extension is everything after last period, ignores period at start)
		exists (returns true if directory or path exists)	
os.utime(path, (atime, mtime)) - set access and modified times of the file at path.

os.system("bash command")
open(filename, mode) - opens a file in mode r (read) w (write) or a (append)
f.close() - closes file object "f".
 


shutil.move(src, dst) - recursively move a file or directory to another location (non-existing)
shutil.copy2(src, dst) - copy file and metadata src to file or directory dst overwriting like-named files

""" 
from Tkinter import *
import os
import sys
import shutil
import filecmp
import tempfile
import tkMessageBox



		

class File(object):
	def __init__(self, path):
		self.path = path
		self.stat = os.stat(self.path)
		self.size = os.path.getsize(self.path)
		self.birthTime = self.stat.st_birthtime
		self.accessTime = os.path.getatime(self.path)
		self.modTime = os.path.getmtime(self.path)
		self.owner = self.stat.st_uid
		self.ext = os.path.splitext(path)[1]
		self.nameext = self.setNameExt()
		self.name = self.setName()
		self.dir = self.setContDir()
	
	#returns string of the name of file + ext
	def setNameExt(self):
		if os.path.isdir(self.path):
			splitpath = self.path.split("/")
			return splitpath[len(splitpath) - 2]
		else:
			splitpath = self.path.split("/")
			return splitpath[len(splitpath) - 1]

	#returns string of the name of file
	def setName(self):
		splitname = self.nameext.split(".")
		return splitname[0]


	#returns the path of the containing directory of self
	def setContDir(self):
		splitpath = self.path.split("/")
		splitpath.remove(splitpath[len(splitpath) - 1])
		if splitpath[len(splitpath) - 1] == "/":
			splitpath.remove(len(splitpath) - 1)
		if self.path.startswith("/"):
			dirpath = ""
		else:
			dirpath = "/"
		for i in splitpath:
			dirpath += i + "/"
		return dirpath


	#returns only the name of the containing folder
	#inputs: None
	#outputs: string
	def getContDirSolo(self):
		splitpath = self.path.split("/")
		pathA = splitpath[len(splitpath) - 2]
		foldername = ".../" + pathA + "/"
		return foldername
	
	#changes the file extention of the self to str.
	#inputs: self, string
	#outputs: None
	def changeExt(self, string):
		if string[0] != ".":
			string = "." + string
		os.rename(self.path, self.dir + self.name + string)
	
	#changes the file extention of all files in containing directory that have same extention as selected file.
	#inputs: self, string
	#outputs: None
	def changeExtAllSame(self, string):
		listA = os.listdir(self.dir)
		listB = []
		#put same extention files in listB
		for i in listA:
			fileA = File(self.dir + i)
			if fileA.ext == self.ext:
				listB += [fileA]
		#change extention of listB files.
		for i in listB:
			if string[0] != ".":
				string = "." + string
			os.rename(i.path, i.dir + i.name + string)
	#appends str to the beginning of self's file name.
	#inputs: self, string
	#outputs: None
	def appendNameBeg(self, str):
		os.rename(self.path, self.dir + str + self.nameext)

	#appends str to the end of self's file name.
	#inputs: self, string
	#outputs: None
	def appendNameEnd(self, str):
		os.rename(self.path, self.dir + self.name + str + self.ext)

	#removes the first itteration of string "str" from self's file name.
	#inputs: self, string
	#outputs: None
	def removeFromName(self, str):
		if self.nameext.find(str) != -1:
			newname = self.nameext[:self.nameext.find(str)] + self.nameext[self.nameext.find(str) + len(str):]
			os.rename(self.path, self.dir + newname)

	def replaceText(self, stringA, stringB):
		stringloc = self.name.find(stringA)
		name = self.name
		if stringloc != -1:
			newname = name[:stringloc] + stringB + name[(stringloc + len(stringA)):]
			os.rename(self.path, self.dir + newname + self.ext)
			File(self.dir + newname + self.ext).replaceText(stringA, stringB)
		return



class Folder(File):
	def __init__(self, path):
		File.__init__(self, path)
		self.path = self.correctPath()
		self.dir = self.containingDir()
		self.listdir = os.listdir(self.path)
		self.listdirnh = listdir_nohidden(self.path)

	#if self is a directory, this method will ensure that it's path ends with a "/" for ease of use with other methods.
	#outputs: string containing a path ending in "/"
	def correctPath(self):
		if os.path.isdir(self.path):
			if self.path[len(self.path) - 1] == "/":
				return self.path
			else:
				return self.path + "/"
		else:
			return self.path

	#returns the path of the containing directory of the current directory.
	#inputs:path
	#outputs: string
	def containingDir(self):
		splitpath = self.path.split("/")
		splitpath.remove(splitpath[len(splitpath) - 1])
		splitpath.remove(splitpath[len(splitpath) - 1])
		if self.path.startswith("/"):
			newpath = ""
		else:
			newpath = "/"
		for i in splitpath:
			newpath += i + "/"
		return newpath

	#Moves the contents of "self" to the directory "dest" (string) which must already exist, then deletes the empty directory "self."
	#inputs: self, string
	#outputs: none
	def moveContents(self, dest):
		list = os.listdir(self.path)
		while not list == []:
			Npath = dest + list[0]
			if not os.path.exists(Npath):
				print Npath, "-- ok to move."
				shutil.move(self.path + list[0], dest)
				list.remove(list[0])				
			else:
				if list[0] == ".DS_Store":
					os.remove(self.path + list[0])
					list.remove(list[0])
				else:
					print self.path + list[0], "-- already exists in destination directory."
					list.remove(list[0])
		if list == []:
			os.rmdir(self.path)
			print self.path, "-- Directory deleted."
		else:
			print self.path, "-- Directory is not empty."

	#Move contents of all subdirectories up one heirarchy
	#inputs: self
	#outputs: none
	def moveSubDirContentsUp(self):
		mlist = self.listdirnh
		nlist = []
		for item in mlist:
			if os.path.isdir(self.path + item):
				nlist += [Folder(self.path + item)]
		for folder in nlist:
			folder.moveContents(self.path)


	#Creates a Directory with name "string" inside of the current Folder Object.
	#inputs: self, string
	#outputs: none
	def createDirectory(self, string):
		os.mkdir(self.correctPath() + string)


	#Compares the items in self and FolderB, overwriting older files in self if newer ones (according to last modified) exist in FolderB, if item in FolderB doesn't exist in self, it is copied to self. Finally deletes FolderB.
	#inputs: Folder Object (Source for merge, not destination)
	#outputs: None
	def mergeDirs(self, FolderB):
		listA = []
		listB = []
		for i in self.listdir:
			if os.path.isdir(self.correctPath() + i):
				listA += [Folder(self.correctPath() + i + "/")]
			else:
				listA += [File(self.correctPath() + i)]
		for i in FolderB.listdir:
			if os.path.isdir(FolderB.correctPath() + i):
				listB += [Folder(FolderB.correctPath() + i + "/")]
			else:
				listB += [File(FolderB.correctPath() + i)]
		#Compare similar items and choose most recent one to place in "self"; remove from FolderB the files that already exist in exact or newer form in self.
		for itemA in listA:
			for itemB in listB:
				if itemA.nameext == itemB.nameext and os.path.isdir(itemA.path):
					itemA.mergeDirs(itemB)
				elif itemB.nameext == itemA.nameext and itemB.birthTime == itemA.birthTime and itemB.modTime > itemA.modTime:
					os.remove(itemA.path)
					shutil.move(itemB.path, itemA.dir)
				elif itemB.nameext == itemA.nameext and itemB.birthTime == itemA.birthTime and itemB.modTime == itemA.modTime and itemB.size == itemA.size:
					os.remove(itemB.path)
					listB.remove(itemB)
		#If Folder B has any items that self does not have, move them to self.
		for itemB in listB:
			if not os.path.exists(self.correctPath() + itemB.nameext):
				shutil.move(itemB.path, self.correctPath())
			else:
				os.remove(itemB.path)
				listB.remove(itemB)
		#Verify that FolderB is now empty and, if so, delete it.
		for item in os.listdir(FolderB.path):
			os.remove(FolderB.path + item)
			listB.remove(itemB)

		if os.listdir(FolderB.path) == []:
			os.removedirs(FolderB.path)
			
		else:
			print "Folder B still contains files and will therefore not be deleted."

	#returns a list of all the files in the directory tree as File type objects
	#Outputs: None
	def indexAllFiles(self):
		index = []
		for item in self.listdirnh:
			if os.path.isdir(self.path + item):
				i = Folder(self.path + item)
				index += i.indexAllFiles()
			else:
				i = File(self.path + item)
				index += [i]
		return index

	#searches a directory tree of self for duplicate files (only compares contents) and returns them in a list of lists of Master file followed by all of its duplicates.
	#Outputs: List of lists of duplicate files as file objects
	def findDupes(self, path):
		allsubfiles = self.indexAllFiles()
		dupes = []
		if self.path == path:
			print "folders are identical"
			return []
		if path == "":
			for itemA in allsubfiles:
				indexA = allsubfiles.index(itemA)
				restoffiles = allsubfiles[indexA + 1:]
				Aitem = open(itemA.path)
				Aread = Aitem.read(2048)
				dupecounter = 0
				#loop through all files after itemA (so as not to check for duplicity against itself or those with which it has already been checked) and adds them to "dupesofA" or not.
				dupesofA = [itemA]
				for itemB in restoffiles:
					Bitem = open(itemB.path)
					Bread = Bitem.read(2048)
					#if the file is not identical to itself, the first 1024 bytes are compared to assess whether the files are identical.  If not, they are added to the dupesofA list and removed from the allsubfiles list (because their duplicity no longer matters).
					if itemA.path != itemB.path and Aread == Bread:
						dupesofA += [itemB]
						allsubfiles.remove(itemB)
						dupecounter += 1
					Bitem.close()
				Aitem.close()
				#Only files that return duplicates will be added to "dupes" list.
				if dupecounter != 0:
					dupes += [dupesofA]
			return [len(dupes), dupes]
		else:
			FolderB = Folder(path)
			allsubfilesB = FolderB.indexAllFiles()
			for itemA in allsubfiles:
				Aitem = open(itemA.path)
				Aread = Aitem.read(1024)
				dupecounter = 0
				dupesofA = [itemA]
				for itemB in allsubfilesB:
					Bitem = open(itemB.path)
					Bread = Bitem.read(1024)
					if Aread == Bread:
						dupesofA += [itemB]
						allsubfilesB.remove(itemB)
						dupecounter += 1
					Bitem.close()
				Aitem.close()
				if dupecounter != 0:
					dupes += [dupesofA]
			return [len(dupes), dupes]		



	#searches a given directory tree for "string" in the files/folders' names, returns list of Folder objects that contained that string 
	#output: list of results of query as file objects
	def searchDir(self, str):
		founditems = []
		for item in listdir_nohidden(self.path):
			i = FileorFolder(self.path +item)
			if i.nameext.find(str) != -1:
				founditems += [i]
			elif os.path.isdir(i.path):
				founditems += i.searchDir(str)
		return founditems



	#removes the directory's name from the name of the files contained in that directory.
	#output: None
	def removeDirName(self):
		for i in self.listdirnh:
			if i.find(self.name) != -1:
				newname = i[:self.nameext.find(self.name)] + i[self.nameext.find(self.name) + len(self.name):]
				os.rename(self.path + i, self.path + newname)

	#Appends the directory name to the beginning of every file contained in that directory if it doesn't already contain that text.
	#Output: None
	def appendDirName(self):
		for i in self.listdirnh:
			if not i.startswith(self.name):
				os.rename(self.path + i, self.path + self.name + i)

	#removes the directory's name from the name of the files contained in that directory.
	#output: None
	def removefromContentsName(self, str):
		for i in self.listdirnh:
			File(self.path + i).removeFromName(str)


	#Appends the string to the end of every file name contained in that directory.
	#Output: None
	def appendtoContentsNameEnd(self, str):
		for i in self.listdirnh:
			fileA = File(self.dir + i)
			fileA.appendNameEnd(str)

	#Appends the string to the beginning of every file name contained in directory.
	#Output: None
	def appendtoContentsNameBeg(self, str):
		for i in self.listdirnh:
			fileA = File(self.dir + i)
			fileA.appendNameBeg(str)

	def replaceAllContents(self, stringA, stringB):
		for i in self.listdirnh:
			File("/" + self.dir + i).replaceText(stringA, stringB)

#Makes a File or Folder Object with the given path
#inputs: string
#outputs: File or Folder object
def FileorFolder(path):
	if os.path.isdir(path):
		return Folder(path)
	else:
		return File(path)

#Takes in a path and returns the directory listing for that path, removing the hidden files that start will "."
#input: path
#output: list			
def listdir_nohidden(path):
	listdir = []
	for item in os.listdir(path):
		if not item.startswith('.') and not item.startswith('$'):
			listdir += [item]
	return listdir

"""
The next section of code is dedicated to providing an accessible user interface through which the previous code can be implimented.






"""

#A modified version of Tkinter's ListBox that involves a file or folder path and some methods for updating the list (emulates a file browser)
class MyListBox(Listbox):
	def __init__(self, root, path):
		Listbox.__init__(self, root)
		self.path = path

	#Returns path ending in "/" if self is a directory and doesn't already end in "/"
	#output: string
	def correctPath(self):
		if os.path.isdir(self.path):
			if self.path[len(self.path) - 1] == "/":
				return self.path
			else:
				return self.path + "/"
		else:
			return self.path

	#returns the path of the containing directory of self
	#outpu: string
	def setContDir(self):
		splitpath = self.correctPath().split("/")
		splitpath.remove(splitpath[len(splitpath) - 1])
		splitpath.remove(splitpath[len(splitpath) - 2])
		dirpath = "/"
		if not len(splitpath) == 0:
			if splitpath[0] == [""]:
				splitpath.remove(splitpath[0])
			dirpath = "/"
			for i in splitpath:
				dirpath += i + "/"
		if len(dirpath) > 1:
			dirpath = dirpath[:len(dirpath)-1]
		return dirpath

	#changes the contents of the listbox to reflect the selected directory parent directory.
	#inputs: self, stringVariable, event
	#outputs: none
	def changeDirUp(self, pathvar, event):
		pathvar.set(self.setContDir())
		self.path = self.setContDir()
		self.delete(0, END)
		self.listContents()

	#changes the contents of the listbox to reflect the selected directory's contents.
	#inputs: self, stringVariable, string, event
	#outputs: none
	def changeDir(self, pathvar, event):
		if event == "Home":
			self.path = os.path.expanduser("~/")
		elif self.size() == 0 and event != "BackSpace" and event != "Return" and event != "LeftClick":
			self.path = "/"
		else:
			item = self.get(ACTIVE)
			if item[len(item) - 1] == "/":
				item == item[:len(item) - 1]
			if os.path.isdir(self.correctPath() + item):
				self.path = self.correctPath() + item
		self.delete(0, END)
		self.listContents()
		pathvar.set(self.path)

	#clears listbox of all contents.
	def clearContents(self, pathvar):
		self.delete(0, END)
		pathvar.set("")


	#display the contents of the directory in the listbox.
	def listContents(self):
		for x in listdir_nohidden(self.path):
			if os.path.isdir(self.correctPath() + x):
				self.insert(END, x + "/")
			else:
				self.insert(END, x)
		self.xview(0)

def printResults(item):
	print "Number of duplicates: ", item[0]
	print
	print
	itemB = item[1]
	listpaths = []
	if type(itemB) == list:
		if type(itemB[0]) == list:
			for i in itemB:
				listpathsA = []
				for x in i:
					listpathsA += [x.getContDirSolo() + x.nameext]
				print listpathsA
			print
			print

	else:
		print item
		print 
		print



#open containing folder in the Finder
#input: list of file or folder objects
#output: none
def openFinder(objlist):
	for x in objlist:
		if os.path.isdir(x.path):
			os.system("open " + x.path)
		else:
			os.system("open " + x.dir)

#Returns the item in the listbox that has been selected.
#inputs: event, listBox
#output: string
def getSelection(choices, event):
	items = list(choices.curselection())
	if items != []:
		index = int(items[0])
		if event == "Up":
			if index != 0:
				return choices.get(index - 1)
			else:
				return choices.get(0)
		elif event == "Down":
			if index != choices.size() - 1:
				return choices.get(index + 1)
			else:
				return choices.get(index)
		else:
			return choices.get(index)
	else:
		if event == "Up":
			return choices.get(0)
		elif event == "Down":
			return choices.get(1)
		elif event == "LeftClick":
			return choices.get(ACTIVE)

#displays a message box alerting the user of the action's success.
def success():
	tkMessageBox.showwarning("Success!", "Your action has been successfully performed!")

#displays a message box telling the user that the action has failed.
def fail():
	tkMessageBox.showerror("Error!", "There appears to be a problem. Please check that you have provided the necessary information for the desired task, then try again.")


#Performs the action selected in the optionBox on the selected file or folder(s). Alerts the user as to their successful completion or failure.
#inputs: string, string, string, string
#output: none or printed strings
def performAction(pathA, pathB, vEntry, vEntryA, action):
	if pathA != "":
		if action == "Merge Directories":
			if os.path.isdir(pathA) and os.path.isdir(pathB) and pathA != pathB:
				Folder(pathA).mergeDirs(Folder(pathB))
				success()
			else:
				print "Your selections in Side A and Side B must both be directories and they must not be identical."
				fail()
		elif action == "Search":
			if os.path.isdir(pathA) and vEntry != "":
				printResults(Folder(pathA).findDupes(pathB))
				success()
			else:
				print "Please ensure that you have placed your text criteria into the text Entry Field and that the selected item in Side A is a directory."
				fail()
		elif action == "Append Folder Name to Contents":
			if os.path.isdir(pathA):
				Folder(pathA).appendDirName()
				success()
			else:
				print "Your selection needs to be a directory for this function to work."
				fail()
		elif action == "Remove Folder Name from Contents":
			if os.path.isdir(pathA):
				Folder(pathA).removeDirName()
				success()
			else:
				print "Your selection needs to be a directory for this function to work."
				fail()
		elif action == "Find Duplicate Files":
			if os.path.isdir(pathA):

				printResults(Folder(pathA).findDupes(pathB))
				success()
			else:
				print "Your selection needs to be a directory for this function to work."
				fail()
		elif action == "Move Folder Contents":
			if os.path.isdir(pathA) and os.path.isdir(pathB):
				Folder(pathA).moveContents(pathB)
				success()
			else:
				print "This function requires that your selection in both Side A and Side B refer to directories."
				fail()
		elif action == "Append Text to Beginning of File Name":
			if vEntry != "":
				File(pathA).appendNameBeg(vEntry)
				success()
			else:
				print "You have provided no text to append."
				fail()
		elif action == "Append Text to End of File Name":
			if vEntry != "":
				File(pathA).appendNameEnd(vEntry)
				success()
			else:
				print "You have provided no text to append."
				fail()
		elif action == "Remove Text from File Name":
			if vEntry != "":
				File(pathA).removeFromName(vEntry)
				success()
			else:
				print "You have provided no text to remove."
				fail()
		elif action == "Change File Extension":
			if vEntry != "" and not os.path.isdir(pathA):
				File(pathA).changeExt(vEntry)
				success()
			else:
				print "You must provide a replacement extention and your selection in Side A must be a file and not a directory"
				fail()
		elif action == "New Folder":
			if vEntry != "":
				Folder(pathA).createDirectory(vEntry)
				success()
			else:
				print "You need to enter a name for the new Folder."
				fail()
		elif action == "Change Extention of all Same-Type Files":
			if vEntry != "" and not os.path.isdir(pathA):
				File(pathA).changeExtAllSame(vEntry)
				success()
			else:
				print "The selected file must not be a directory and you must enter a new file extention."
				fail()
		elif action == "Append Text to the Beginning of All Contained Files' Names.":
			if vEntry != "" and os.path.isdir(pathA):
				Folder(pathA).appendtoContentsNameBeg(vEntry)
				success()
			else:
				"You must provide a directory and text."
				fail()
		elif action == "Append Text to the End of All Contained Files' Names.":
			if vEntry != "" and os.path.isdir(pathA):
				Folder(pathA).appendtoContentsNameEnd(vEntry)
				success()
			else:
				"You must provide a directory and text."
				fail()
		elif action == "Remove Text from of All Contained Files' Names.":
			if vEntry != "" and os.path.isdir(pathA):
				Folder(pathA).removefromContentsName(vEntry)
				success()
			else:
				"You must provide a directory and text."
				fail()
		elif action == "Replace all instances of text in upper field with text in lower field.":
			if vEntry != "" and vEntryA != "":
				File(pathA).replaceText(vEntry, vEntryA)
				success()
			else:
				"You must provide text in both fields."
				fail()
		elif action == "Replace text in all subfiles subfolders.":
			if vEntry != "" and vEntryA != "":
				Folder(pathA).replaceAllContents(vEntry, vEntryA)
				success()
			else:
				"You must provide text in both fields and your selection in Side A must be a folder."
				fail()
		elif action == "Move Contents of Subdirectories Up":
			if os.path.isdir(pathA):
				Folder(pathA).moveSubDirContentsUp()
				success()
			else:
				print "The item you selcted is not a directory."
				fail()
	else:	
		print "You have not selected a file or directory."
		fail()


#User Interface Implimentation
def fileHelper():
	#initiate a Tkinter "root" window specs.
	root = Tk()
	root.title("FileHelper - Your Orginizational Solution")
	root.geometry("1000x700-200+50")
	root.resizable(0, 0)

	#List of all the different action possibilities *will appear in the drop down action chooser.
	OPTIONS = ["Merge Directories", "Search", "Append Folder Name to Contents", "Remove Folder Name from Contents", "Find Duplicate Files", "Move Folder Contents", "Append Text to Beginning of File Name", "Append Text to End of File Name", "Remove Text from File Name", "Append Text to the End of All Contained Files' Names.", "Append Text to the Beginning of All Contained Files' Names.", "Remove Text from of All Contained Files' Names.", "Replace all instances of text in upper field with text in lower field.", "Replace text in all subfiles subfolders.", "Change File Extension", "Change Extention of all Same-Type Files", "New Folder", "Move Contents of Subdirectories Up"]


	#Create Menu Bar
	menubar = Menu(root)
	filemenu = Menu(menubar, tearoff=0)
	filemenu.add_command(label = "Save results as text file...")
	filemenu.add_separator()
	filemenu.add_command(label="Quit", command=sys.exit)
	menubar.add_cascade(label="File", menu=filemenu)
	actionmenu = Menu(menubar, tearoff=0)
	for x in OPTIONS:
		actionmenu.add_command(label = x, command = lambda: performAction(vA.get(), vB.get(), vEntry.get(), x))
	menubar.add_cascade(label="Action", menu=actionmenu)
	


	#Frame encompassing entire window
	MainWindow = Frame(root, bg= "#FFFFFF", borderwidth = 5)
	MainWindow.pack(fill = BOTH, pady = 10, expand = 1)
	

	#Left-side Frame involving Browser A, labels, and buttons.
	frameA = Frame(MainWindow, bg= "#FFFFFF")
	frameA.pack(side = LEFT, fill = BOTH, expand = 1)

	#Middle Frame involving current selection displays, action chooser, and text fields
	frameB = Frame(MainWindow, bd = 5, bg = "#FFFFFF")
	frameB.pack(side = LEFT,  fill = BOTH, expand = 1)

	#Right-side Frame involving Browser B, labels, and buttons.
	frameC = Frame(MainWindow, bg = "#FFFFFF")
	frameC.pack(side = LEFT, fill = BOTH, expand = 1)


	#Perform Action Button and Text Fields and Selector drop down.(TOP MIDDLE)
	frameE = Frame(frameB, bg = "#FFFFFF")
	frameE.pack(side = TOP, fill = X)
	
	#Selection display of Side A
	frameBMiddle = Frame(frameB, bd = 5, bg = "#FFFFFF")
	frameBMiddle.pack(fill = BOTH, expand = 1)

	#Selection display of Side B
	frameBMiddleB = Frame(frameB, bd = 5, bg = "#FFFFFF")
	frameBMiddleB.pack(fill = BOTH, expand = 1)
	

	#option box refering to the action the user would like to perform
	action = ""
	var = StringVar(MainWindow)
	var.set("Select Option") # initial value
	option = OptionMenu(frameE, var, *OPTIONS)
	option.pack(side = TOP)



	


	#Initiation of empty filebrowsing boxes with labels and location indicators.
	choicesALabel = Label(frameA, text = "Side A\nChoose a File or Directory in:")
	choicesALabel.pack(padx = 30, side = TOP)

	pathAvar = StringVar()
	pathALabel = Label(frameA, textvariable = pathAvar, wraplength = 240, height = 3)
	pathALabel.pack()


	
	#Scrolling list box of current directory contents
	frameChA = Frame(frameA, bg = "#FFFFFF")
	
	ScrollA = Scrollbar(frameChA, orient = VERTICAL)
	choicesA = MyListBox(frameChA, "")
	
	

	ScrollA.config(command = choicesA.yview)
	choicesA.config(yscrollcommand = ScrollA.set, width = 30, height = 18)
	
	#When mouse is in FrameA, focus on choicesA.
	frameA.bind("<Enter>", lambda e: choicesA.focus_set())

	#Key and button actions dedicated to choicesA when it is in focus.
	choicesA.bind("<Double-Button-1>", lambda e: choicesA.changeDir(pathAvar, "LeftClick"))
	choicesA.bind("<ButtonRelease-1>", lambda e: vA.set(choicesA.correctPath() + getSelection(choicesA, "LeftClick")))
	choicesA.bind("<Return>", lambda e: choicesA.changeDir(pathAvar, "Return"))
	choicesA.bind("<BackSpace>", lambda e: choicesA.changeDirUp(pathAvar, "BackSpace"))
	choicesA.bind("<Left>", lambda e: choicesA.changeDirUp(pathAvar, "Left"))
	choicesA.bind("<Right>", lambda e: choicesA.changeDir(pathAvar, "Right"))
	choicesA.bind("<Up>", lambda e: vA.set(choicesA.correctPath() + getSelection(choicesA, "Up")))
	choicesA.bind("<Down>", lambda e: vA.set(choicesA.correctPath() + getSelection(choicesA, "Down")))
	choicesA.bind("<Home>", lambda e: choicesA.changeDir(pathAvar, "Home"))
	

	#Button allowing user to wipe SideA clear of any file location
	clearA = Button(frameA, text = "Clear", command = lambda: choicesA.clearContents(pathAvar))
	clearA.pack()


	#Button to display the current directory's parent directory.
	backA = Button(frameA, text = "Up", command = lambda: choicesA.changeDirUp(pathAvar, "Left"))
	backA.pack()
	
	
	frameChA.pack(fill = Y)
	ScrollA.pack(side = RIGHT, fill = Y)
	choicesA.pack(fill = Y, side = BOTTOM)

	#Button to trigger the display of the users Home folder in Side A
	bHomeA = Button(frameA, text = "Home Directory", command = lambda: choicesA.changeDir(pathAvar, "Home"))
	bHomeA.pack(side = TOP)
	



	choicesBLabel = Label(frameC, text = "Side B\nChoose a File or Directory in:")
	choicesBLabel.pack(padx = 30, side = TOP)


	pathBvar = StringVar()
	pathBLabel = Label(frameC, textvariable = pathBvar, wraplength = 240, height = 3)
	pathBLabel.pack()

	
	
	frameChB = Frame(frameC, bg = "#FFFFFF")
	
	#scrolling listbox of current directory contents Side B
	ScrollB = Scrollbar(frameChB, orient = VERTICAL)
	choicesB = MyListBox(frameChB, "")
	
	ScrollB.config(command = choicesA.yview)
	choicesB.config(yscrollcommand = ScrollB.set, width = 30, height = 18)
	
	#When mouse is in Frame C, choicesB is in focus.
	frameC.bind("<Enter>", lambda e: choicesB.focus_set())

	#Key and button actions dedicated to choicesB when it is in focus.
	choicesB.bind("<Double-Button-1>", lambda e: choicesB.changeDir(pathBvar, "LeftClick"))
	choicesB.bind("<ButtonRelease-1>", lambda e: vB.set(choicesB.correctPath() + getSelection(choicesB, "LeftClick")))
	choicesB.bind("<Return>", lambda e: choicesB.changeDir(pathBvar, "Return"))
	choicesB.bind("<BackSpace>", lambda e: choicesB.changeDirUp(pathBvar, "BackSpace"))
	choicesB.bind("<Left>", lambda e: choicesB.changeDirUp(pathBvar, "Left"))
	choicesB.bind("<Right>", lambda e: choicesB.changeDir(pathBvar, "Right"))
	choicesB.bind("<Up>", lambda e: vB.set(choicesB.correctPath() + getSelection(choicesB, "Up")))
	choicesB.bind("<Down>", lambda e: vB.set(choicesB.correctPath() + getSelection(choicesB, "Down")))
	choicesB.bind("<Home>", lambda e: choicesB.changeDir(pathBvar, "Home"))

	
	clearB = Button(frameC, text = "Clear", command = lambda: choicesB.clearContents(pathBvar))
	clearB.pack()

	#Button to display the current directory's parent directory.
	backB = Button(frameC, text = "Up", command = lambda: choicesB.changeDirUp(pathBvar, "Left"))
	backB.pack()


	frameChB.pack(fill = Y)
	ScrollB.pack(side = RIGHT, fill = Y)
	choicesB.pack(fill = Y, side = BOTTOM)


	#Button to trigger the display of the users Home folder in Side A
	bHomeB = Button(frameC, text = "Home Directory", command = lambda: choicesB.changeDir(pathBvar, "Home"))
	bHomeB.pack(side = TOP)

	currentLabel = Label(frameBMiddle, text = "Your Current Selections:")
	currentLabel.pack(pady = 20, padx = 90)

	currentLabel = Label(frameBMiddle, text = "<-- Left")
	currentLabel.pack()
	
	#Currently selected file or folder path for Side A
	vA = StringVar()
	eA = Label(frameBMiddle, textvariable= vA, wraplength = 240, height = 4)
	eA.pack()
	
	currentLabel = Label(frameBMiddleB, text = "Right -->")
	currentLabel.pack()

	#Currently selected file or folder path for Side B
	vB = StringVar()
	eB = Label(frameBMiddleB, textvariable=vB, wraplength = 240, height = 4)
	eB.pack()


	vEntry = StringVar()
	eEntry = Entry(frameE, textvariable = vEntry)
	eEntry.pack(side = TOP)

	vEntryA = StringVar()
	eEntryA = Entry(frameE, textvariable = vEntryA)
	eEntryA.pack(side = TOP)

	#create button to perform whichever action is selected in the optionBox.
	bAction = Button(frameE, text = "Perform Action", command = lambda: performAction(vA.get(), vB.get(), vEntry.get(), vEntryA.get(), var.get()))
	bAction.pack(side = TOP)
	


	#create button to quit.
	bQuit = Button(root, text = "Quit", command = sys.exit)
	bQuit.pack(side = BOTTOM and RIGHT)

	

	#display menubar
	root.config(menu=menubar)


	#loop program
	root.mainloop()

	
if __name__ == "__main__":
	fileHelper()
